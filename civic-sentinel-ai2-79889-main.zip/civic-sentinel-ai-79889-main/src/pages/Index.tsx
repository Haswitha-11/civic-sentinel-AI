import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FileText, Shield, Users } from "lucide-react";
import landingHero from "@/assets/landing-hero.jpg";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${landingHero})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-primary/95 to-secondary/90" />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-16">
        <div className="text-center mb-16 animate-fade-in">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-white rounded-full mb-6 shadow-2xl">
            <FileText className="w-12 h-12 text-primary" />
          </div>
          <h1 className="text-6xl font-bold text-white mb-6 drop-shadow-lg">
            Public Grievance System
          </h1>
          <p className="text-2xl text-white mb-4 drop-shadow-md max-w-3xl mx-auto">
            AI-Powered Analysis and Prioritization for Better Governance
          </p>
          <p className="text-lg text-white/90 drop-shadow-md max-w-2xl mx-auto">
            Connecting Citizens with Government Departments for Efficient Problem Resolution
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-12">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-10 shadow-2xl hover:shadow-3xl transition-all transform hover:scale-105 border-2 border-primary/20">
            <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-primary to-primary/80 rounded-full mb-6 shadow-lg">
              <Users className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold mb-3 text-primary">Citizen Portal</h2>
            <p className="text-muted-foreground mb-8 text-lg">
              Submit and track your grievances. Get real-time updates and resolutions from relevant departments.
            </p>
            <Button 
              onClick={() => navigate("/auth")} 
              className="w-full text-lg py-6 shadow-lg hover:shadow-xl"
              size="lg"
            >
              <Users className="w-5 h-5 mr-2" />
              Citizen Login
            </Button>
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-10 shadow-2xl hover:shadow-3xl transition-all transform hover:scale-105 border-2 border-secondary/20">
            <div className="flex items-center justify-center w-20 h-20 bg-gradient-to-br from-secondary to-secondary/80 rounded-full mb-6 shadow-lg">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-3xl font-bold mb-3 text-secondary">Department Administration</h2>
            <p className="text-muted-foreground mb-8 text-lg">
              Manage grievances efficiently with AI-powered categorization and priority detection.
            </p>
            <Button 
              onClick={() => navigate("/admin-auth")} 
              className="w-full text-lg py-6 shadow-lg hover:shadow-xl"
              variant="secondary"
              size="lg"
            >
              <Shield className="w-5 h-5 mr-2" />
              Admin Login
            </Button>
          </div>
        </div>

        <div className="max-w-4xl mx-auto bg-white/90 backdrop-blur-sm rounded-xl p-8 shadow-xl">
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div className="p-4">
              <div className="text-4xl font-bold text-primary mb-2">AI-Powered</div>
              <p className="text-sm text-muted-foreground">Intelligent categorization and analysis</p>
            </div>
            <div className="p-4">
              <div className="text-4xl font-bold text-secondary mb-2">Multilingual</div>
              <p className="text-sm text-muted-foreground">Support for 4 major languages</p>
            </div>
            <div className="p-4">
              <div className="text-4xl font-bold text-accent mb-2">Transparent</div>
              <p className="text-sm text-muted-foreground">Track your grievance status in real-time</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;