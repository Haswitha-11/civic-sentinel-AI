import { Globe } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLanguage } from "@/contexts/LanguageContext";
import { getTranslation, Language } from "@/utils/translations";

const LanguageSelector = () => {
  const { language, setLanguage } = useLanguage();
  const t = (key: string) => getTranslation(language, key as any);

  return (
    <div className="flex items-center gap-2">
      <Globe className="w-4 h-4 text-muted-foreground" />
      <Select value={language} onValueChange={(value: Language) => setLanguage(value)}>
        <SelectTrigger className="w-[140px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="en">{t('english')}</SelectItem>
          <SelectItem value="kn">{t('kannada')}</SelectItem>
          <SelectItem value="hi">{t('hindi')}</SelectItem>
          <SelectItem value="te">{t('telugu')}</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default LanguageSelector;
