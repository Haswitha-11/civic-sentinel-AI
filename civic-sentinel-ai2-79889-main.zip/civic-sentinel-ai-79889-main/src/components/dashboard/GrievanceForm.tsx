import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Loader2, Upload } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { getTranslation } from "@/utils/translations";

interface GrievanceFormProps {
  userId: string;
  onSuccess: () => void;
}

const GrievanceForm = ({ userId, onSuccess }: GrievanceFormProps) => {
  const { language } = useLanguage();
  const t = (key: string) => getTranslation(language, key as any);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let attachmentUrl = null;

      // Upload file if present
      if (file) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/${Date.now()}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('grievance-attachments')
          .upload(fileName, file);

        if (uploadError) {
          throw uploadError;
        }

        const { data: { publicUrl } } = supabase.storage
          .from('grievance-attachments')
          .getPublicUrl(fileName);
        
        attachmentUrl = publicUrl;
      }

      // Call edge function to analyze and create grievance
      const { data, error } = await supabase.functions.invoke('analyze-grievance', {
        body: {
          title,
          description,
          location,
          attachment_url: attachmentUrl,
          user_id: userId
        }
      });

      if (error) throw error;

      toast.success("Grievance submitted successfully!");
      setTitle("");
      setDescription("");
      setLocation("");
      setFile(null);
      onSuccess();
    } catch (error: any) {
      console.error('Error:', error);
      toast.error(error.message || "Failed to submit grievance");
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="title">{t('title')} *</Label>
        <Input
          id="title"
          placeholder={t('titlePlaceholder')}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">{t('description')} *</Label>
        <Textarea
          id="description"
          placeholder={t('descriptionPlaceholder')}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={6}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="location">{t('location')}</Label>
        <Input
          id="location"
          placeholder={t('locationPlaceholder')}
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="file">{t('attachment')}</Label>
        <div className="flex items-center gap-2">
          <Input
            id="file"
            type="file"
            accept="image/*,.pdf"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="cursor-pointer"
          />
          {file && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setFile(null)}
            >
              {t('remove')}
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground">
          {t('uploadHint')}
        </p>
      </div>

      <Button type="submit" disabled={loading} className="w-full">
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            {t('analyzing')}
          </>
        ) : (
          <>
            <Upload className="mr-2 h-4 w-4" />
            {t('submitButton')}
          </>
        )}
      </Button>
    </form>
  );
};

export default GrievanceForm;