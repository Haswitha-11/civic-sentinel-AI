import { useState, useEffect } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LogOut, Shield, TrendingUp, AlertCircle, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import GrievanceList from "./GrievanceList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import adminBg from "@/assets/admin-bg.jpg";

interface AdminDashboardProps {
  user: User;
}

interface Department {
  id: string;
  name: string;
}

const AdminDashboard = ({ user }: AdminDashboardProps) => {
  const navigate = useNavigate();
  const [grievances, setGrievances] = useState<any[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>("high");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    
    // Fetch grievances with department info
    const { data: grievancesData, error: grievancesError } = await (supabase as any)
      .from("grievances")
      .select(`
        *,
        departments (
          id,
          name
        )
      `)
      .order("created_at", { ascending: false });

    if (grievancesError) {
      toast.error("Failed to load grievances");
      console.error(grievancesError);
    } else {
      setGrievances(grievancesData || []);
    }

    // Fetch departments
    const { data: departmentsData, error: departmentsError } = await supabase
      .from("departments")
      .select("id, name")
      .order("name");

    if (departmentsError) {
      toast.error("Failed to load departments");
      console.error(departmentsError);
    } else {
      setDepartments(departmentsData || []);
    }

    setLoading(false);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  const handleStatusUpdate = async (grievanceId: string, newStatus: string) => {
    const { error } = await (supabase as any)
      .from("grievances")
      .update({ 
        status: newStatus,
        resolved_at: newStatus === "resolved" ? new Date().toISOString() : null
      })
      .eq("id", grievanceId);

    if (error) {
      toast.error("Failed to update status");
    } else {
      toast.success("Status updated successfully");
      fetchData();
    }
  };

  const stats = {
    total: grievances.length,
    pending: grievances.filter(g => g.status === "pending").length,
    inProgress: grievances.filter(g => g.status === "in_progress").length,
    resolved: grievances.filter(g => g.status === "resolved").length,
  };

  // Get grievances by priority level
  const getGrievancesByPriority = (priority: string) => {
    if (priority === "high") {
      return grievances.filter(g => g.priority === "high" || g.priority === "critical");
    }
    return grievances.filter(g => g.priority === priority);
  };

  // Get grievances by department within a priority level
  const getGrievancesByDepartment = (priority: string, departmentId: string) => {
    const priorityGrievances = getGrievancesByPriority(priority);
    return priorityGrievances.filter(g => g.department_id === departmentId);
  };

  // Count grievances for a department within a priority
  const countDepartmentGrievances = (priority: string, departmentId: string) => {
    return getGrievancesByDepartment(priority, departmentId).length;
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-priority-critical/10 text-priority-critical border-priority-critical";
      case "medium":
        return "bg-priority-medium/10 text-priority-medium border-priority-medium";
      case "low":
        return "bg-priority-low/10 text-priority-low border-priority-low";
      default:
        return "";
    }
  };

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${adminBg})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-background/95 to-background/90" />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="bg-card/90 backdrop-blur-sm border-b sticky top-0 z-20 shadow-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl font-bold">Admin Dashboard</h1>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
            </div>
            <Button variant="outline" onClick={handleSignOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8">
          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-card/90 backdrop-blur-sm shadow-lg">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <div className="text-2xl font-bold">{stats.total}</div>
                </div>
                <p className="text-sm text-muted-foreground">Total Grievances</p>
              </CardContent>
            </Card>
            <Card className="bg-card/90 backdrop-blur-sm shadow-lg">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="w-5 h-5 text-status-pending" />
                  <div className="text-2xl font-bold text-status-pending">{stats.pending}</div>
                </div>
                <p className="text-sm text-muted-foreground">Pending</p>
              </CardContent>
            </Card>
            <Card className="bg-card/90 backdrop-blur-sm shadow-lg">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-status-in-progress mb-2">{stats.inProgress}</div>
                <p className="text-sm text-muted-foreground">In Progress</p>
              </CardContent>
            </Card>
            <Card className="bg-card/90 backdrop-blur-sm shadow-lg">
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-status-resolved" />
                  <div className="text-2xl font-bold text-status-resolved">{stats.resolved}</div>
                </div>
                <p className="text-sm text-muted-foreground">Resolved</p>
              </CardContent>
            </Card>
          </div>

          {/* Priority → Department → Complaints Structure */}
          <Card className="bg-card/90 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle>Grievance Management</CardTitle>
              <CardDescription>
                Complaints organized by priority level and department
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3 mb-6">
                  <TabsTrigger value="high" className="text-priority-critical">
                    High Priority
                  </TabsTrigger>
                  <TabsTrigger value="medium" className="text-priority-medium">
                    Medium Priority
                  </TabsTrigger>
                  <TabsTrigger value="low" className="text-priority-low">
                    Low Priority
                  </TabsTrigger>
                </TabsList>
                
                {["high", "medium", "low"].map((priority) => (
                  <TabsContent key={priority} value={priority} className="space-y-6">
                    {departments.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        No departments found
                      </div>
                    ) : (
                      departments.map((dept) => {
                        const deptGrievances = getGrievancesByDepartment(priority, dept.id);
                        const count = deptGrievances.length;
                        
                        return (
                          <Card 
                            key={dept.id} 
                            className={`border-2 ${getPriorityColor(priority)}`}
                          >
                            <CardHeader>
                              <div className="flex items-center justify-between">
                                <CardTitle className="text-lg">{dept.name}</CardTitle>
                                <Badge variant="secondary" className="text-sm">
                                  {count} {count === 1 ? "Complaint" : "Complaints"}
                                </Badge>
                              </div>
                            </CardHeader>
                            <CardContent>
                              {count === 0 ? (
                                <p className="text-sm text-muted-foreground text-center py-4">
                                  No {priority} priority complaints in this department
                                </p>
                              ) : (
                                <GrievanceList
                                  grievances={deptGrievances}
                                  loading={loading}
                                  showUserInfo={true}
                                  isAdmin={true}
                                  onStatusUpdate={handleStatusUpdate}
                                />
                              )}
                            </CardContent>
                          </Card>
                        );
                      })
                    )}
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;