import { useState, useEffect } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LogOut, Plus, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useLanguage } from "@/contexts/LanguageContext";
import { getTranslation } from "@/utils/translations";
import GrievanceForm from "./GrievanceForm";
import GrievanceList from "./GrievanceList";
import LanguageSelector from "@/components/LanguageSelector";
import citizenBg from "@/assets/citizen-bg.jpg";

interface CitizenDashboardProps {
  user: User;
}

const CitizenDashboard = ({ user }: CitizenDashboardProps) => {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const t = (key: string) => getTranslation(language, key as any);
  const [showForm, setShowForm] = useState(false);
  const [grievances, setGrievances] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchGrievances();
  }, [user.id]);

  const fetchGrievances = async () => {
    setLoading(true);
    const { data, error } = await (supabase as any)
      .from("grievances")
      .select(`
        *,
        departments (
          id,
          name
        )
      `)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Failed to load grievances");
      console.error(error);
    } else {
      setGrievances(data || []);
    }
    setLoading(false);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  return (
    <div className="min-h-screen relative">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${citizenBg})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-background/95 to-background/90" />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="bg-card/90 backdrop-blur-sm border-b sticky top-0 z-20 shadow-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <FileText className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl font-bold">{t('citizenPortal')}</h1>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <LanguageSelector />
              <Button variant="outline" onClick={handleSignOut}>
                <LogOut className="w-4 h-4 mr-2" />
                {t('logout')}
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8">
          {/* Stats Overview */}
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-card/90 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-primary">{grievances.length}</div>
                <p className="text-sm text-muted-foreground">{t('totalGrievances')}</p>
              </CardContent>
            </Card>
            <Card className="bg-card/90 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-status-pending">
                  {grievances.filter(g => g.status === "pending").length}
                </div>
                <p className="text-sm text-muted-foreground">{t('pending')}</p>
              </CardContent>
            </Card>
            <Card className="bg-card/90 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-status-in-progress">
                  {grievances.filter(g => g.status === "in_progress").length}
                </div>
                <p className="text-sm text-muted-foreground">{t('inProgress')}</p>
              </CardContent>
            </Card>
            <Card className="bg-card/90 backdrop-blur-sm">
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-status-resolved">
                  {grievances.filter(g => g.status === "resolved").length}
                </div>
                <p className="text-sm text-muted-foreground">{t('resolved')}</p>
              </CardContent>
            </Card>
          </div>

          {/* Actions */}
          <div className="mb-6">
            <Button onClick={() => setShowForm(!showForm)} size="lg" className="shadow-lg">
              <Plus className="w-4 h-4 mr-2" />
              {showForm ? "Cancel" : t('submitGrievance')}
            </Button>
          </div>

          {/* Grievance Form */}
          {showForm && (
            <div className="mb-8 animate-fade-in">
              <Card className="bg-card/90 backdrop-blur-sm shadow-xl">
                <CardHeader>
                  <CardTitle>{t('grievanceForm')}</CardTitle>
                  <CardDescription>
                    AI will automatically categorize your grievance
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <GrievanceForm
                    userId={user.id}
                    onSuccess={() => {
                      setShowForm(false);
                      fetchGrievances();
                    }}
                  />
                </CardContent>
              </Card>
            </div>
          )}

          {/* Grievances List */}
          <Card className="bg-card/90 backdrop-blur-sm shadow-xl">
            <CardHeader>
              <CardTitle>{t('myGrievances')}</CardTitle>
              <CardDescription>
                Track the status of your submitted grievances
              </CardDescription>
            </CardHeader>
            <CardContent>
              <GrievanceList
                grievances={grievances}
                loading={loading}
                showUserInfo={false}
              />
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
};

export default CitizenDashboard;