import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, MapPin, AlertCircle, FileText, User } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface GrievanceListProps {
  grievances: any[];
  loading: boolean;
  showUserInfo?: boolean;
  isAdmin?: boolean;
  onStatusUpdate?: (grievanceId: string, newStatus: string) => void;
}

const GrievanceList = ({
  grievances,
  loading,
  showUserInfo = false,
  isAdmin = false,
  onStatusUpdate
}: GrievanceListProps) => {
  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (grievances.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">No grievances found</h3>
        <p className="text-muted-foreground">
          {isAdmin ? "No grievances match your filters" : "You haven't submitted any grievances yet"}
        </p>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: "bg-status-pending",
      in_progress: "bg-status-in-progress",
      resolved: "bg-status-resolved",
      rejected: "bg-status-rejected"
    };
    return colors[status] || "bg-muted";
  };

  const getPriorityColor = (priority: string) => {
    const colors: Record<string, string> = {
      critical: "bg-priority-critical",
      high: "bg-priority-high",
      medium: "bg-priority-medium",
      low: "bg-priority-low"
    };
    return colors[priority] || "bg-muted";
  };

  return (
    <div className="space-y-4">
      {grievances.map((grievance) => (
        <Card key={grievance.id} className="border-l-4" style={{
          borderLeftColor: `hsl(var(--priority-${grievance.priority}))`
        }}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-lg mb-2">{grievance.title}</CardTitle>
                <CardDescription className="text-sm">
                  {grievance.description}
                </CardDescription>
              </div>
              <div className="flex gap-2 ml-4">
                <Badge className={`${getStatusColor(grievance.status)} text-white`}>
                  {grievance.status.replace('_', ' ')}
                </Badge>
                <Badge className={`${getPriorityColor(grievance.priority)} text-white`}>
                  {grievance.priority}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 text-sm">
              {grievance.departments && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <FileText className="w-4 h-4" />
                  <span>Department: {grievance.departments.name}</span>
                </div>
              )}
              
              {grievance.location && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span>{grievance.location}</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>
                  Submitted {formatDistanceToNow(new Date(grievance.created_at), { addSuffix: true })}
                </span>
              </div>

              {grievance.ai_summary && (
                <div className="mt-2 p-3 bg-muted rounded-lg">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="font-medium text-sm mb-1">AI Summary</div>
                      <p className="text-sm text-muted-foreground">{grievance.ai_summary}</p>
                    </div>
                  </div>
                </div>
              )}

              {isAdmin && onStatusUpdate && (
                <div className="mt-3 flex items-center gap-3">
                  <span className="text-sm font-medium">Update Status:</span>
                  <Select
                    value={grievance.status}
                    onValueChange={(value) => onStatusUpdate(grievance.id, value)}
                  >
                    <SelectTrigger className="w-[200px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default GrievanceList;