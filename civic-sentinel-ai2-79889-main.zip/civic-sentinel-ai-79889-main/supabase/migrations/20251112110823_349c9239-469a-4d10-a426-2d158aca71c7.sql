-- Create storage bucket for grievance attachments
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'grievance-attachments',
  'grievance-attachments',
  true,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'application/pdf']
);

-- Allow authenticated users to upload their own files
CREATE POLICY "Users can upload their own grievance attachments"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'grievance-attachments' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow authenticated users to view their own files
CREATE POLICY "Users can view their own grievance attachments"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'grievance-attachments' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow admins to view all grievance attachments
CREATE POLICY "Admins can view all grievance attachments"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'grievance-attachments' AND
  has_role(auth.uid(), 'admin')
);

-- Allow public read access to all attachments since grievances are viewable
CREATE POLICY "Public can view grievance attachments"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'grievance-attachments');