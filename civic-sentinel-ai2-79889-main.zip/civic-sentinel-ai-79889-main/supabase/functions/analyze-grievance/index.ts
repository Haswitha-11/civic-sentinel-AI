import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { title, description, location, attachment_url, user_id } = await req.json();

    console.log('Analyzing grievance:', { title, user_id });

    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Call Lovable AI for analysis
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    const prompt = `Analyze this public grievance and provide:
1. Best matching department from: Electricity Department, Water Supply & Drainage Department, Municipal Corporation / Sanitation Department, Public Works Department (PWD), Transport Department / RTO, Police Department, Health Department
2. Priority level: critical, high, medium, or low
3. Sentiment score from -1.0 (very negative) to 1.0 (very positive)
4. A brief 1-2 sentence summary in English

Note: The complaint may be written in English, Kannada (ಕನ್ನಡ), Hindi (हिंदी), or Telugu (తెలుగు). Analyze it regardless of language.

Title: ${title}
Description: ${description}
${location ? `Location: ${location}` : ''}

Respond in JSON format:
{
  "department": "department name",
  "priority": "priority level",
  "sentiment": 0.0,
  "summary": "brief summary in English"
}`;

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { 
            role: 'system', 
            content: 'You are an AI assistant specialized in analyzing public grievances for government departments. Always respond with valid JSON.' 
          },
          { role: 'user', content: prompt }
        ],
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('AI API error:', aiResponse.status, errorText);
      throw new Error(`AI analysis failed: ${aiResponse.status}`);
    }

    const aiData = await aiResponse.json();
    const aiContent = aiData.choices[0].message.content;
    
    console.log('AI response:', aiContent);

    // Parse AI response
    let analysis;
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = aiContent.match(/```(?:json)?\s*([\s\S]*?)\s*```/) || [null, aiContent];
      const jsonStr = jsonMatch[1] || aiContent;
      analysis = JSON.parse(jsonStr.trim());
    } catch (e) {
      console.error('Failed to parse AI response:', aiContent);
      // Fallback to default values
      analysis = {
        department: "General",
        priority: "medium",
        sentiment: 0,
        summary: description.substring(0, 150)
      };
    }

    // Find department ID
    const { data: deptData } = await supabase
      .from('departments')
      .select('id')
      .ilike('name', analysis.department)
      .maybeSingle();

    let departmentId = deptData?.id;

    // If department not found by exact match, try partial match
    if (!departmentId) {
      const { data: departments } = await supabase
        .from('departments')
        .select('id, name');
      
      if (departments) {
        const dept = departments.find(d => 
          d.name.toLowerCase().includes(analysis.department.toLowerCase()) ||
          analysis.department.toLowerCase().includes(d.name.toLowerCase())
        );
        departmentId = dept?.id;
      }
    }

    // Create grievance
    const { data: grievance, error: insertError } = await supabase
      .from('grievances')
      .insert({
        user_id,
        title,
        description,
        location,
        attachment_url,
        department_id: departmentId,
        priority: analysis.priority,
        sentiment_score: analysis.sentiment,
        ai_summary: analysis.summary,
        status: 'pending'
      })
      .select()
      .single();

    if (insertError) {
      console.error('Insert error:', insertError);
      throw insertError;
    }

    console.log('Grievance created:', grievance.id);

    return new Response(
      JSON.stringify({ 
        success: true, 
        grievance,
        analysis 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error: any) {
    console.error('Error in analyze-grievance:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});